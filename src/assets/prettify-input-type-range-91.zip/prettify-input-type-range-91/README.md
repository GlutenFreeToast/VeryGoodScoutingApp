# prettify `<input type=range>` #91

A Pen created on CodePen.

Original URL: [https://codepen.io/thebabydino/pen/bNQeeV](https://codepen.io/thebabydino/pen/bNQeeV).

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 36, 39 (nightly), Chrome 41, 43 (canary)/ Opera 28, IE 11 on Windows 8. Very little JS needed. 

Has a little nice extra in Chrome/ Opera - the turn off symbol on the thumb. This s achieved by using a pseudo element on the thumb. This is something that didn't work until recently, so I'm also using `/deep/` - careful, experimental stuff, only supported in Blink, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), no future really, already not working anymore in canary - see ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). 

Fallback for no JS: no highlighted cubes before the thumb. 

---

If the work I've been putting out since early 2012 has helped you in any way or you just like it, then please remember that praise doesn't keep me afloat financially... but you can! So please consider supporting my work in one of the following ways:

* being a cool cat 😼🎩 and supporting it monthly on Ko-fi or via a one time donation

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* making a weekly anonymous donation via Liberapay - I'll never know who you are if that's your wish

[![Liberapay](https://assets.codepen.io/2017/btn_liberapay.svg)](https://liberapay.com/anatudor/)

* getting me a chocolate voucher

[![Zotter chocolate](https://assets.codepen.io/2017/zotter.jpg)](https://www.zotter.at/en/online-shop/gifts/gift-vouchers/choco-voucher)

* if you're from outside Europe, becoming a patron on Patreon (don't use it for one time donations or if you're from Europe, we're both getting ripped off)

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* or at least sharing this to show the world what can be done with CSS these days

Thank you!

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/PyFvP1o.gif) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).  